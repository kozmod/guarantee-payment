CREATE PROCEDURE [dbo].[INSERT_DIC_COUNT_Type]   
--declare
	@Name		varchar(100) = null
	,@New_name	varchar(100) = null
AS 
/*  
exec dbo.INSERT_DIC_COUNT_Type  
@Name= 'ДДД' 
*/ 
BEGIN    

	declare   
		@ID_Type	int = null   
		,@ID		int = null  
		
	declare    
		@OutputTbl TABLE (ID INT)   
		
	--set @Name= case when @Name= '-1' or @Nameis null then @New_Nameelse @Nameend   
	
	BEGIN TRAN  
	
		--проверяем новое имя   
		--ищем элемент  
		
		SELECT 
			@ID_Type = ID_Type
			, @ID = ID 
		FROM [dbo].[DIC_Count_Type] (NOLOCK) 
		WHERE 
			Name = @Name
			and dell = 0   

			--SELECT @ID, @ID_Type
	
		--удаляем его  
		
		IF not exists(SELECT 1 FROM [dbo].[DIC_COUNT_Type] (nolock) WHERE Name = @New_Name and dell = 0) 
			UPDATE [dbo].[DIC_Count_Type]    
				set dell = 1  
			OUTPUT DELETED.ID into @OutputTbl
			WHERE 
				ID_Type = @ID_Type    
		ELSE
			UPDATE [dbo].[DIC_Count_Type] 
				set  dell = 1 
			WHERE 
				ID_Type = @ID_Type  
				
				
		
		
		IF (@Name = '-1' or @Name is null or @ID is null) --новый элемент или не существующий старый
			Begin  
				IF (@ID IS NULL) 
					begin
					rollback;
					return; --если старый не существует, то ошибка
					end
				--вставляем новый
				INSERT INTO  [dbo].[DIC_Count_Type]([ID_Type],[NAME])    
				SELECT top 1     
					isnull(max(ID_Type)+1,-1)     
					,@New_Name   
				FROM  [dbo].[DIC_Count_Type](nolock)     
				
				
				IF (Select count(1) FROM [dbo].[DIC_Count_Type] (nolock) ) = 0     
					INSERT INTO  [dbo].[DIC_Count_Type]([ID_Type],[Name]) VALUES (1,@New_Name)   
					
			End    
			
		ELSE  
			Begin   
			
			--SELECT @ID_Type =  isnull(max(ID_Type),-1) FROM [dbo].[DIC_Count_Type](nolock)    
			
			--вставляем его в таблицу      
			
				if exists(SELECT  1 FROM [dbo].[DIC_COUNT_Type] CN (nolock) inner join @OutputTbl T on T.id = CN.id)  
					begin
						--чистим буферную табличку
						delete from @OutputTbl
						 --старое на новое 
						INSERT INTO [dbo].[DIC_Count_Type]([ID_Type],[Name])
							OUTPUT INSERTED.id INTO @OutputTbl  
						VALUES (@ID_Type, @New_name) 
					end
				else    
						INSERT INTO @OutputTbl
						select 
							ID
						FROM [dbo].[DIC_COUNT_Type] (nolock) 
						WHERE 
							1=1
							and Name = @New_Name
							and dell = 0        
							
							
						
					
					
				IF object_id('tempdb..#FRK_ACCOUNT_COUNT_TYPE_Type_temp') is not null    
					drop table #FRK_ACCOUNT_COUNT_TYPE_Type_temp    
					
				CREATE TABLE #FRK_ACCOUNT_COUNT_TYPE_Type_temp (               
																ID_ACCOUNT	int
																,ID_Type	int
																,ID_Count	int
																,ID_TYPE	int               
																)    
																
				--удаляем его из таблицы зависимостей   
				UPDATE [dbo].[FRK_ACCOUNT_COUNT_TYPE_Type]    
					set dell = 1   
				OUTPUT     
					DELETED.ID_ACCOUNT    
					,DELETED.ID_Type    
					,DELETED.ID_Type    
					,DELETED.ID_TYPE   
				into #FRK_ACCOUNT_COUNT_TYPE_Type_temp   
				WHERE ID_Type = @ID       
				
				INSERT INTO dbo.FRK_ACCOUNT_COUNT_TYPE_Type (ID_ACCOUNT, ID_Type, ID_Count, ID_TYPE)   
				SELECT     
					FRK.ID_ACCOUNT    
					,O.ID    
					,FRK.ID_Type    
					,FRK.ID_TYPE   
				FROM #FRK_ACCOUNT_COUNT_TYPE_Type_temp FRK   
				cross join @OutputTbl O  
			End  
				
	commit tran;  
end
go

