/****** Скрипт для команды SelectTopNRows из среды SSMS  ******/

CREATE proc [dbo].[sp_Sync_Site]
as
begin

SET NOCOUNT ON;

declare
	@maxID int = null
	,@maxDateSync datetime = null

Select @maxID = max(CN.id_Count) From [dbo].[DIC_Count_Name]  CN (nolock) where CN.dell = 0
Select @maxDateSync = max([DateSync]) From [dbo].[TIME_Sync] (nolock)

Select 
 [SiteNumber]
      ,[TypeHome]
      ,[NContract]
      ,[DateContract]
      ,[SmetCost]
      ,[SumCost]
      ,[FinishBuilding]
      ,[Contractor]
      ,[CostHouse]
      ,[CostSite]
      ,[SaleClients]
      ,[DebtClients]
      ,[StatusPayment]
      ,[StatusJobs]
      ,[QueueBuilding]
      ,[SaleHouse]
      ,[NumberSession]
      ,[k]
      ,[dell]
      ,[DateCreate]
      ,[SiteTypeID]
into #Site
From STAGE.dbo.Site (NOLOCK)
where DateCreate >= @maxDateSync
and dell = 0

if @@ROWCOUNT = 0 
	return;

INSERT INTO [dbo].[DIC_Count_Name] ([id_Count],[Name])
Select @maxID + row_number() over (order by R.[Contractor]), R.[Contractor] 
From
	(Select S.[Contractor] From #Site S (NOLOCK) where dell is null
	EXCEPT
	Select [Name] From[dbo].[DIC_Count_Name] where dell = 0
	)R



INSERT INTO Test.dbo.Site_new(
	[SiteNumber]
      ,[TypeHome]
      ,[NContract]
      ,[DateContract]
      ,[SmetCost]
      ,[SumCost]
      ,[FinishBuilding]
      ,[id_Count]
      ,[CostHouse]
      ,[CostSite]
      ,[SaleClients]
      ,[DebtClients]
      ,[StatusPayment]
      ,[StatusJobs]
      ,[QueueBuilding]
      ,[SaleHouse]
      ,[NumberSession]
      ,[k]
      ,[dell]
      ,[DateCreate]
      ,[SiteTypeID])
SELECT  
      S.[SiteNumber]
      ,S.[TypeHome]
      ,S.[NContract]
      ,S.[DateContract]
      ,S.[SmetCost]
      ,S.[SumCost]
      ,S.[FinishBuilding]
      ,Isnull(DCN.id_count, -1) as id_Count
      ,S.[CostHouse]
      ,S.[CostSite]
      ,S.[SaleClients]
      ,S.[DebtClients]
      ,S.[StatusPayment]
      ,S.[StatusJobs]
      ,S.[QueueBuilding]
      ,S.[SaleHouse]
      ,S.[NumberSession]
      ,S.[k]
      ,S.[dell]
      ,S.[DateCreate]
      ,S.[SiteTypeID]
  FROM #Site S
  outer apply (Select top 1 DCN.id_Count From Test.[dbo].[DIC_Count_Name] DCN  (NOLOCK) Where S.Contractor = DCN.Name and DCN.DELL = 0 ) DCN


INSERT INTO [dbo].[TIME_Sync]  with(rowlock) ([DateSync])
select max(DateCreate)
From #Site

END
go

