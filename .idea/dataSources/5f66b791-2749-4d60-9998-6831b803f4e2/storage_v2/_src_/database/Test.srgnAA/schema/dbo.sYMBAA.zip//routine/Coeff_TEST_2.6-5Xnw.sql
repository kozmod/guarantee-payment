

CREATE PROC [dbo].[Coeff_TEST_2]
@SiteNumber	varchar(10) = null
,@Contractor	varchar(100) = null
		
 as

 SET NOCOUNT ON;

 IF Object_id('tempdb..#Site') is not null
	drop table #Site

Create table #Site(
				[Contractor]	[nvarchar](100) 	collate database_default		NOT NULL
				,[SiteNumber]	[nvarchar](10) 		collate database_default		NOT NULL	
				,[SaleHouse]	[float]												NULL
				,[Type]			[int]
				,[Value]		[float]
				,[dell]			[bit]
				,[RN]			[int]
				)

insert into #Site (
						[Contractor]	
						,[SiteNumber]	
						,[SaleHouse]	
						,[Type]			
						,[Value]		
						,[dell]			
						,[RN]	
					)
	Select
		S.[Contractor]
		,S.[SiteNumber]	
		,S.[SaleHouse]
		,SE.[Type]
		,SE.[Value]
		, S.dell
		,Row_number() over(partition by S.[Contractor],S.[SiteNumber] order by SE.[id]) as RN
--	into #Site
	From  [dbo].[Site] S
	left join [dbo].[SiteExpenses] SE
		on SE.[Contractor] = S.[Contractor]
		and SE.[SiteNumber] = S.[SiteNumber]
		and SE.dell = 0
	where 
		S.dell = 0
		--




declare 
	@FinPlane int = (Select sum(F.[Quantity]) from [dbo].[FinPlan] F where F.dell = 0)
	,@OSR decimal(28,2) = (Select sum(value) as value From  [dbo].[SiteOSR] OSR where dell = 0)


if OBJECT_ID('TempDB..#HouseCost') is not null
	drop table #HouseCost

create table #HouseCost
	(SaleHouse	decimal(28,2)
	,SmetCost	decimal(28,2)
	)

insert into #HouseCost(SaleHouse, SmetCost)
Select 
	sum(Case when SaleHouse < 0 then 0 else SaleHouse end +House) as SaleHouse
	,sum(case when SmetCost < 0 then 0 else SmetCost end + Cost) as SmetCost
From

(
		Select
			(MAX(F.Quantity) - count(S.[SiteTypeID]))*max(F.SaleCost)	as SaleHouse
			,sum(S.SaleHouse)											as House
			,(max(F.Quantity) - count(F.[TypeID]))*max(F.SmetCost)		as SmetCost
			,sum(S.SmetCost)											as Cost
		From dbo.[Site] S 
		Inner JOIN dbo.[FinPlan] F              
			ON F.[TypeID] = S.[SiteTypeID]
			and F.dell = 0  
		where 
			S.dell = 0
		group by
			F.[TypeID] 
		union all
		Select 
			max(F.[Quantity])*max(F.SaleCost)
			,0
			,max(F.[Quantity])*max(F.SmetCost)
			,0
		From dbo.[FinPlan] F              
		Inner JOIN dbo.[Site] S 
			ON F.[TypeID] = S.[SiteTypeID]
			and F.dell = 0  
		group by 
			F.[TypeID] 
		having sum(cast(S.dell as int)) = count(F.[TypeID] )
				
)C



	;with
		CTE as (Select 
					S.[RN]
					,case	when S.[Type] = 0 then S.[SaleHouse]-S.[SaleHouse] * cast(S.Value as decimal(28,2)) / 100 
							when S.[Type] = 1 then S.[SaleHouse] - cast(S.Value as decimal(28,2))
					else  S.[SaleHouse]
					end	as [Res]
					,S.[Contractor]
					,S.[SiteNumber]
				--	,S.[id]
				From  #Site S
				Where 
					S.RN = 1 
					and S.dell = 0
				union all
				Select
					S.[RN]
					,case	when S.[Type] = 0 then C.[Res]-C.[Res] * cast(S.Value as decimal(28,2)) / 100 
							when S.[Type] = 1 then C.[Res] - cast(S.Value as decimal(28,2))
					else  C.[Res]
					end	as [Res]
					,S.[Contractor]
					,S.[SiteNumber]
					--,S.[id]
				From CTE C 
				join #Site S
					on S.[Contractor]	= C.[Contractor]
					and S.[SiteNumber]	= C.[SiteNumber]
					--and S.dell = 0
					and S.RN			= C.RN+1
					
			)
			
				Select 
					CTE.[Contractor]
					,CTE.[SiteNumber]
					,min(CTE.Res)		as [SiteExpeses]
					,@OSR				as [OSR]
					,@FinPlane			as [Quantity]
					,max(HC.SaleHouse)	as [SaleHouseSumALL]
					,max(HC.SmetCost )	as [SmetCostSumALL]
					,(SELECT SUM(F.[SaleCost]*F.[Quantity]) FROM dbo.[FinPlan] F) as[SaleCostSumFromFinPlan]
					,(SELECT [INCOMTAX] FROM dbo.[TBL_COMMAND_PROPERTY] WHERE  [dell] = 0 ) as [INCOMTAX]
					,(SELECT [sale_Exp] FROM dbo.[TBL_COMMAND_PROPERTY] WHERE  [dell] = 0 ) as [sale_Exp]
				From CTE	
				cross join #HouseCost	HC	
				Where 
					(CTE.Contractor = @Contractor or     @Contractor is null)
					and (CTE.SiteNumber = @SiteNumber or @SiteNumber is null)	 	
				Group by 
					CTE.[Contractor]
					,CTE.[SiteNumber]


SET NOCOUNT OFF;

go

